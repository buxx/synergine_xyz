from synergine_xyz.display.object.Visualisation import Visualisation


class ImageTraceVisualisation(Visualisation):

    def get_path(self):
        return self._value