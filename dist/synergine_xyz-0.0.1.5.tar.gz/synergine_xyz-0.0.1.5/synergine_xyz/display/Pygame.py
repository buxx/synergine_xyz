from synergine_xyz.display.PygameDisplay import PygameDisplay as XyPygame


class Pygame(XyPygame):
  pass