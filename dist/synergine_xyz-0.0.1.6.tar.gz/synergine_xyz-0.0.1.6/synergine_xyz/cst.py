from synergine.lib.eint import IncrementedNamedInt


POSITION = IncrementedNamedInt.get('xyz.position')
POSITIONS = IncrementedNamedInt.get('xyz.positions')
PREVIOUS_DIRECTION = IncrementedNamedInt.get('xyz.previous_direction')
BLOCKED_SINCE = IncrementedNamedInt.get('xyz.blocked_since')
